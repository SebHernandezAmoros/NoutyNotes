---
assetRefs:
  - assets/images/image-2.png
contentPresent: true
fields: {}
id: tarjeta-1
schemaVersion: 11
title: Nueva nota
titleVisibility: hidden
typeId: nota
---
![image-2](assets/images/image-2.png)

<!-- nouty-caption:v1:%5B%7B%22type%22%3A%22text%22%2C%22text%22%3A%22Leyenda%20hist%C3%B3rica%20exacta%22%7D%5D -->