---
cardIds:
  - tarjeta-1
descriptionPresent: false
id: principal
schemaVersion: 1
title: Tablero principal
---
